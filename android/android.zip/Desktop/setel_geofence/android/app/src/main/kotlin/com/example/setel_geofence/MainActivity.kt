package com.example.setel_geofence

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
